<?php

$this->load->view('template/common_header');
$this->load->view('template/navigation');
$this->load->view($page);
$this->load->view('template/common_footer');


 ?>